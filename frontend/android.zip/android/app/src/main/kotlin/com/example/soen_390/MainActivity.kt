package com.example.soen_390

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
